===========================
CS 381 - Programming Lab #1
===========================


To run test t01

$ raku lab1.raku < ./tests/t01.in

Compare your result with t01.out


Likewise, run t02.in to compare with t02.out, and so on. 
